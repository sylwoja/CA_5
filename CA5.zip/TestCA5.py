# -*- coding: utf-8 -*-
"""
Created on Fri Nov 16 19:05:50 2018

@author: swojc
"""

# CA 5 : Calculator with Lmabda, Map, Reduce etc.
#Student number: 10392584

# testing 
import unittest

from CA5 import add, multiply, subtract, divide, cube, squareRoot, factorial, sin, square, cos

class CalculatorTest(unittest.TestCase):
    
    def testAdd(self):
        self.assertEqual(6, add([1,2,3]))
        self.assertEqual(8, add([2,2,4]))
        self.assertEqual(20, add([5,6,9]))
        self.assertEqual(8, add([-2,5,5]))
        
    def testMultiply(self):
        self.assertEqual(8, multiply([2,2,2]))
        self.assertEqual(20, multiply([5,2,2]))
        self.assertEqual(15, multiply([-5,-1, 3]))
        self.assertEqual(-24, multiply([2,-6, 2]))
        self.assertEqual(0, multiply([32,0, 5]))
        self.assertEqual(4.5, multiply([15,0.6, 0.5]))
    
    def testSubtract(self):
        self.assertEqual(7, subtract([5,3,-5]))
        self.assertEqual(-44, subtract([9,8, 45]))
        self.assertEqual(-30.1, subtract([70,100, 0.1]))
        self.assertEqual(2.6, subtract([-5,-8, 0.4]))
        
    def testDivide(self):
        self.assertRaises(ZeroDivisionError, divide,([10,0,5]))
        self.assertEqual(-0.6, divide([9,-3,5]))
        self.assertEqual(3.6, divide([90,12.5,2]))
        self.assertEqual(0.12, divide([18,50,3]))
        self.assertRaises(ZeroDivisionError, divide, [4,5,0])
        
    def testCube(self):
        self.assertEqual([8, 64, 125], cube([2, 4,5]))
        self.assertEqual([125,27,216], cube([5,3, 6]))
        self.assertEqual([216,1000,-125], cube([6,10, -5]))
        self.assertEqual([-216, 0.5120000000000001,1], cube([-6, 0.8,1]))
       
       
    def testSquare(self):
        self.assertEqual([4, 9, 64], square([2,3,8]))
        self.assertEqual([625, 225, 1024], square([-25, 15, 32]))
        self.assertEqual([0.31360000000000005,4, 25 ], square([0.56, 2, -5]))
        self.assertEqual([6400], square([-80]))
        self.assertEqual([0,49,0.25 ], square([0, 7, 0.5]))
    
    def testSquareRoot(self):
        self.assertEqual([4, 5, 7], squareRoot([16, 25, 49]))
        self.assertEqual([4, 5, 9], squareRoot([16, 25, 81]))
        self.assertEqual([2,3,8], squareRoot([4, 9, 64]))
        self.assertEqual([10, 15, 6], squareRoot([100, 225,36]))
        
    def testFactorial(self):
        self.assertEqual([2, 6, 24], factorial([2, 3, 4]))
        self.assertEqual([1, 120, 5040], factorial([0, 5, 7]))
        self.assertEqual([40320, 720, 1], factorial([8, 6, 1 ]))
        
    
    def testSin(self):
        self.assertEqual([-0.27941549819892586, 0.9092974268256817, -0.7568024953079282], sin([6, 2, 4]))
        self.assertEqual([-0.9092974268256817, 0.9589242746631385, -0.6569865987187891], sin([-2, -5, -7]))
        self.assertEqual([-0.5440211108893698, 0.9129452507276277, -0.9880316240928618 ], sin([10, 20, 30]))
        self.assertEqual([0.479425538604203, 0.5646424733950354, 0.19866933079506122], sin([0.5, 0.6, 0.2]))
        
    def testCos(self):
        self.assertEqual([-0.9576594803233847, 0.40808206181339196, -0.7596879128588213], cos([16, 20, 15]))
        self.assertEqual([-0.32328956686350335, 0.5403023058681398,-0.4161468365471424], cos([1.9, 1, 2]))
        self.assertEqual([-0.8578030932449878, 0.28366218546322625, -0.6536436208636119], cos([-78, -5, -4]))
        self.assertEqual([0.022126756261955736, 0.5253219888177297, -0.9364566872907963], cos([55, 45, 3.5]))
    
   
    
if __name__ == '__main__':
    unittest.main()
